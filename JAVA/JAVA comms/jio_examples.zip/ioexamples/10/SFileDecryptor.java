import java.io.*;
import java.security.*;
import java.security.spec.*;
import javax.crypto.*;
import javax.crypto.spec.*;


public class SFileDecryptor {

  public static void main(String[] args) {

    if (args.length != 3) {
      System.err.println("Usage: java SFileDecryptor infile outfile password");
      return;
    }

    String infile = args[0];
    String outfile = args[1];
    String password = args[2];

    if (password.length() < 8 ) {
      System.err.println("Password must be at least eight characters long");
    }
    
    try {

      FileInputStream fis = new FileInputStream(infile);
      FileOutputStream fos = new FileOutputStream(outfile);

      // create a key
      byte[] desKeyData = password.getBytes();
      DESKeySpec desKeySpec = new DESKeySpec(desKeyData);
      SecretKeyFactory keyFactory = SecretKeyFactory.getInstance("DES");
      SecretKey desKey = keyFactory.generateSecret(desKeySpec);

      // use Data Encryption Standard
      Cipher des = Cipher.getInstance("DES/CBC/PKCS5Padding");
      des.init(Cipher.DECRYPT_MODE, desKey);

      byte[] input = new byte[64];
      while (true) {
        int bytesRead = fis.read(input);
        if (bytesRead == -1) break;
        byte[] output = des.update(input, 0, bytesRead);
        if (output != null) fos.write(output);
      }
      
      byte[] output = des.doFinal();
      if (output != null) fos.write(output);
      fis.close();
      fos.flush();
      fos.close();

 
    }
    catch (InvalidKeySpecException e) {
      System.err.println(e);
    }
    catch (InvalidKeyException e) {
      System.err.println(e);
    }
    catch (NoSuchAlgorithmException e) {
      System.err.println(e);
      e.printStackTrace();
    }
    catch (NoSuchPaddingException e) {
      System.err.println(e);
    }
    catch (BadPaddingException e) {
      System.err.println(e);
    }
    catch (IllegalBlockSizeException e) {
      System.err.println(e);
    }
    catch (IOException e) {
      System.err.println(e);
    }

  }

}