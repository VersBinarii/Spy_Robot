import java.net.*;
import java.util.jar.*;
import java.io.*;
import java.security.cert.*;

public class JarTest {

  public static void main(String[] args) throws Exception {
  
     // File f = new File(args[i]);
      URL u = new URL("http://sunsite.unc.edu/javafaq/javaio.jar");
      URL ju = new URL("jar:" + u + "!/com/macfaq/io/DataFilter.class");
      URLConnection juc = u.openConnection();
      System.out.println(juc.getClass());
      System.out.println(u);
      System.out.println(ju);      System.out.println(ju.getFile());
      System.out.println(juc);
      // System.out.println(juc.getURL());
  
  }

}