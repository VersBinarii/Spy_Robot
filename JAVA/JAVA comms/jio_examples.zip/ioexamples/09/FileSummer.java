import java.io.*;
import java.util.zip.*;


public class FileSummer {

  public static void main(String[] args) {

    for (int i = 0; i < args.length; i++) {
      try {
        FileInputStream fin = new FileInputStream(args[i]);      
        System.out.println(args[i] + ":\t" + getCRC32(fin));
        fin.close();
      }
      catch (IOException e) {
        System.err.println(e);     
      }
    }

  }
  
  public static long getCRC32(InputStream in) throws IOException {
  
    Checksum cs = new CRC32();
    
    // It would be more efficient to read chunks of data
    // at a time, but this is simpler and easier to understand
    int b;
    while ((b = in.read()) != -1) {
      cs.update(b);
    }
    return cs.getValue();
  
  }

}
