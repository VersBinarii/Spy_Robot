import java.util.*;
import java.text.*;
import java.io.*;

public class LocaleInfo {

  public static void main(String[] args) throws Exception {
  
    FileOutputStream fout = new FileOutputStream(args[0]);
    OutputStreamWriter osw = new OutputStreamWriter(fout, "UnicodeLittle");
    osw.write(0xFE);
    osw.write(0xFF);
    PrintWriter pw = new PrintWriter(osw);
    Locale list[] = NumberFormat.getAvailableLocales();

    pw.print("Language\tCountry\tPositive prefix\tPositive suffix\t");
    pw.print("Negative prefix\tNegative suffix\tMultiplier\tGrouping Size\t");
    pw.print("isDecimalSeparatorAlwaysShown\tZero Digit\tGrouping Separator\t");
    pw.println(" Decimal Separator\tPercent\tPerMill\tInfinity\tNaN\tMinus Sign");
    for (int i = 0; i < list.length; i++) {
      NumberFormat nsample = NumberFormat.getInstance(list[i]);
      if (nsample instanceof DecimalFormat) {
        DecimalFormat sample = (DecimalFormat) nsample;
        pw.print(list[i].getLanguage() + "\t");
        pw.print(list[i].getCountry() + "\t");
        pw.print(sample.getPositivePrefix() + "\t");
        pw.print(sample.getPositiveSuffix() + "\t");
        pw.print(sample.getNegativePrefix() + "\t");
        pw.print(sample.getNegativeSuffix() + "\t");
        pw.print(sample.getMultiplier() + "\t");
        pw.print(sample.getGroupingSize() + "\t");
        pw.print(sample.isDecimalSeparatorAlwaysShown() + "\t");
        
        DecimalFormatSymbols dfs = sample.getDecimalFormatSymbols();
        pw.print(dfs.getZeroDigit() + "\t");
        pw.print(dfs.getGroupingSeparator() + "\t");
        pw.print(dfs.getDecimalSeparator() + "\t");
        pw.print(dfs.getPercent() + "\t");
        pw.print(dfs.getPerMill() + "\t");
        pw.print(dfs.getInfinity() + "\t");
        pw.print(dfs.getNaN() + "\t");
        pw.print(dfs.getMinusSign());

        
        pw.println();
      }

    }  
    
  }

}