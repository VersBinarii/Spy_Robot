import java.io.*;
import java.util.zip.*;
import javax.swing.*;
import com.macfaq.io.*;


public class GUIGZipper {

  public final static String GZIP_SUFFIX = ".gz";

  public static void main(String[] args) {

    JFrame parent = new JFrame(); // never shown
    JFileChooser fc = new JFileChooser();
    fc.setDialogTitle("Please choose a file to gzip: ");
    fc.setApproveButtonToolTipText(
     "Select a file, then press this button to gzip it");
    fc.setApproveButtonMnemonic('g');

    while (true) {

      int result = fc.showDialog(parent, "GZIP" );
      if (result == JFileChooser.APPROVE_OPTION) {
        try {
          File f = fc.getSelectedFile();
          if (f == null) {
            System.out.println("Can only gzip files, not directories");
            break;
          }
          FileInputStream fin = new FileInputStream(f);
          FileOutputStream fout = new FileOutputStream(f.getAbsolutePath() 
           + GZIP_SUFFIX);
          GZIPOutputStream gzout = new GZIPOutputStream(fout);
          StreamCopier.copy(fin, gzout);
          gzout.close(); 
          fin.close();
          fc.rescanCurrentDirectory();
        }
        catch (IOException e) {
          System.err.println(e);
        }
      }
      else {
        parent.dispose();
        break;
        // exit
      }
    }
    
    // Work around annoying AWT non-daemon thread bug
   System.exit(0);


  }

}
