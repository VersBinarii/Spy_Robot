package com.macfaq.security;

import java.io.*;
import java.security.*;

public class EasyDigestOutputStream extends FilterOutputStream {

  private boolean on = true;
  private boolean closed = false;
  protected byte[] result = null;
  protected MessageDigest digest;

  public EasyDigestOutputStream(OutputStream out, String algorithm)
   throws NoSuchAlgorithmException {
    super(out);
    digest = MessageDigest.getInstance(algorithm);
  }

  public EasyDigestOutputStream(OutputStream out, String algorithm, String provider)
   throws NoSuchAlgorithmException, NoSuchProviderException {
    super(out);
    digest = MessageDigest.getInstance(algorithm, provider);
  }

  public void write(int b) throws IOException {
    if (on) digest.update((byte)b);
    out.write(b);
  }

  public void write(byte[] data, int offset, int length) throws IOException {
    if (on) digest.update(data, offset, length);
    out.write(data, offset, length);
  }

  public void on(boolean on) {
    this.on = on;
  }
  
  public void close() throws IOException {
    out.close();
    result = digest.digest();
    closed = true;
  }
  
  public byte[] getDigest() {
    return result;
  }

}
