import java.io.*;
import java.util.zip.*;
import com.macfaq.io.*;


public class GUnzipper {

  public static void main(String[] args) {

    for (int i = 0; i < args.length; i++) {
      if (args[i].toLowerCase().endsWith(GZipper.GZIP_SUFFIX)) {
        try {
          FileInputStream fin = new FileInputStream(args[i]);      
          GZIPInputStream gzin = new GZIPInputStream(fin);
          FileOutputStream fout = new FileOutputStream(
           args[i].substring(0, args[i].length()-3));
          StreamCopier.copy(gzin, fout);
          fout.close();
        }
        catch (IOException e) {
          System.err.println(e);     
        }
      }
      else {
        System.err.println(args[i] + " does not appear to be a gzipped file.");
      }
    }

  }

}
