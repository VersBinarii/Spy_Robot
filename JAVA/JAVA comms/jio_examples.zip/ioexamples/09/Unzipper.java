import java.util.*;
import java.util.zip.*;
import java.io.*;
import com.macfaq.io.*;


public class Unzipper {

  public static void main(String[] args) {

    for (int i = 0; i < args.length; i++) {
      try {
        ZipFile zf = new ZipFile(args[i]);
        Enumeration e = zf.entries();
        while (e.hasMoreElements()) {
          ZipEntry ze = (ZipEntry) e.nextElement();
          System.out.println("Unzipping " + ze.getName());
          FileOutputStream fout = new FileOutputStream(ze.getName());
          InputStream in = zf.getInputStream(ze);
          StreamCopier.copy(in, fout);
          in.close();
          fout.close();
        }
      }
      catch (IOException e) {
        System.err.println(e);
        e.printStackTrace();
      }       
    }

  }

}
