import java.util.*;
import java.text.*;
import java.io.*;

public class PatternList {

  public static void main(String[] args) throws Exception {
  
    FileOutputStream fout = new FileOutputStream(args[0]);
    OutputStreamWriter osw = new OutputStreamWriter(fout, "UnicodeLittle");
    osw.write(0xFE);
    osw.write(0xFF);
    PrintWriter pw = new PrintWriter(osw);
    Locale list[] = NumberFormat.getAvailableLocales();

    pw.println("Language\tCountry\tPattern");
    for (int i = 0; i < list.length; i++) {
      NumberFormat nsample = NumberFormat.getInstance(list[i]);
      if (nsample instanceof DecimalFormat) {
        pw.print(list[i].getDisplayLanguage());
        pw.print(" (" + list[i].getDisplayCountry() + ")" + "\t");
        DecimalFormat sample = (DecimalFormat) nsample;
        pw.print(sample.toPattern() + "\t"); 
        pw.print(sample.format(-1234.56));
        pw.println();
      }

    }  
    pw.close();
    
  }

}