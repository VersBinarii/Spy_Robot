import java.security.*;
import javax.crypto.*;
import java.io.*;

public class SealPoint {

  public static void main(String[] args) {
  
    TwoDPoint tdp = new TwoDPoint(32, 45);
    
  
  }

}
