import java.io.*;
import javax.swing.*;
import javax.swing.filechooser.*;


public class TestFileView extends FileView {

  public String getName(File f) {
    
    String name = f.getName();
    int lastdot = name.lastIndexOf('.');
    if (lastdot == -1) return name;
    else return name.substring(0, lastdot);
    
  }
    
  public String getTypeDescription(File f) {
   
    String name = f.getName();
    int lastdot = name.lastIndexOf('.');
    if (lastdot != -1) return name.substring(lastdot+1);
    else return null;
    
  }
    
  public Icon getIcon(File f) {
  
    return null;
    
  }
  
  public String getDescription(File f) {
    return "a description";
  }
    
  public Boolean isTraversable(File f) {
    return null; 
  }
  
  public static void main(String[] args) {
      
    JFileChooser fc = new JFileChooser();
    fc.setFileView(new TestFileView());
    int result = fc.showOpenDialog(new JFrame());
    if (result == JFileChooser.APPROVE_OPTION) {
        File f = fc.getSelectedFile();
          if (f != null) {
            System.out.println(f);
          }
        
      }
      
      System.exit(0);
  
  }

}
