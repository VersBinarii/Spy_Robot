import java.io.*;
import java.util.zip.*;
import com.macfaq.io.*;


public class GZipper {

  public final static String GZIP_SUFFIX = ".gz";

  public static void main(String[] args) {

    for (int i = 0; i < args.length; i++) {
      try {
        FileInputStream fin = new FileInputStream(args[i]);      
        FileOutputStream fout = new FileOutputStream(args[i] + GZIP_SUFFIX);
        GZIPOutputStream gzout = new GZIPOutputStream(fout);
        StreamCopier.copy(fin, gzout);
        gzout.close();
      }
      catch (IOException e) {
        System.err.println(e);     
      }
    }

  }

}
