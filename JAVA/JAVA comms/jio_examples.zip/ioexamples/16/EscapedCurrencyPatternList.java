import java.util.*;
import java.text.*;
import java.io.*;
import com.macfaq.io.*;

public class EscapedCurrencyPatternList {

  public static void main(String[] args) throws Exception {
  
    FileOutputStream fout = new FileOutputStream(args[0]);
    Writer osw = new OutputStreamWriter(fout, "UnicodeLittle");
    osw = new SourceWriter(osw);
    osw.write(0xFE);
    osw.write(0xFF);
    PrintWriter pw = new PrintWriter(osw);
    Locale list[] = NumberFormat.getAvailableLocales();

    pw.println("Language (Country)\tPattern\tExample -1,234.56");
    for (int i = 0; i < list.length; i++) {
      NumberFormat nsample = NumberFormat.getCurrencyInstance(list[i]);
      if (nsample instanceof DecimalFormat) {
//        pw.print(list[i].getDisplayLanguage());
        pw.print(list[i].getDisplayName() + "\t");
        DecimalFormat sample = (DecimalFormat) nsample;
        pw.print(sample.toPattern() + "\t"); 
        pw.print(sample.format(-1234.56));
        pw.println();
      }

    }  
    pw.close();
    
  }

}