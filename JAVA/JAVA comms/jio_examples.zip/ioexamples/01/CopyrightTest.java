public class CopyrightTest {

  public static void main(String[] args) {
    char copyright = '�'; 
    System.out.println(copyright + " 1998 Elliotte Rusty Harold");
    System.out.println("� 1998 Elliotte Rusty Harold");
  }
  
}