import java.util.*;
import java.util.zip.*;
import java.io.*;


public class ZipLister {

  public static void main(String[] args) {

    for (int i = 0; i < args.length; i++) {
      try {
        ZipFile zf = new ZipFile(args[i]);
        Enumeration e = zf.entries();
        while (e.hasMoreElements()) {
          System.out.println(e.nextElement());
        }
      }
      catch (IOException e) {
        System.err.println(e);
      }       
    }

  }

}
