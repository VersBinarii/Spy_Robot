import java.net.*;
import java.io.*;
import java.security.*;
import java.math.*;


public class URLDigest {

  public static void main(String[] args) {

    for (int i = 0; i < args.length; i++) {
      try {
        URL u = new URL(args[i]);
        printDigest(u.openStream());
      }
      catch (MalformedURLException e) {
        System.err.println(args[i] + " is not a URL");
      }
      catch (Exception e) {
        System.err.println(e);
      }

    }

  }

  public static void printDigest(InputStream in) 
   throws IOException, NoSuchAlgorithmException {
    
     MessageDigest sha = MessageDigest.getInstance("SHA");
     byte[] data = new byte[128];
     while (true) {
       int bytesRead = in.read(data);
       if (bytesRead < 0) break;
       sha.update(data, 0, bytesRead);
     }
     byte[] result = sha.digest();
     for (int i = 0; i < result.length; i++) {
       System.out.print(result[i] + " ");
     }
     System.out.println();
     System.out.println(new BigInteger(data));

  }

}
