import java.util.zip.*;
import java.io.*;
import com.macfaq.io.*;


public class Zipper {

  public static void main(String[] args) {
  
    if (args.length < 2) {
      System.out.println("Usage: java Zipper [-d level] name.zip file1 file2...");
      return; 
    }
    
    String outputFile = args[0];
    // maximum compression is our default
    int level = 9;
    int start = 1;
    if (args[0].equals("-d")) {
      try {
        level = Integer.parseInt(args[1]);
        outputFile = args[2];
        start = 3;
      }
      catch (Exception e) {
        System.out.println("Usage: java Zipper [-d level] name.zip file1 file2...");
        return;         
      }
    }    
    
    try {
      FileOutputStream fout = new FileOutputStream(outputFile);
      ZipOutputStream zout = new ZipOutputStream(fout);
      zout.setLevel(level);
      for (int i = start; i < args.length; i++) {
        ZipEntry ze = new ZipEntry(args[i]);
        try {
          System.out.println("Compressing " + args[i]);
          FileInputStream fin = new FileInputStream(args[i]);
          zout.putNextEntry(ze);
          StreamCopier.copy(fin, zout);
          zout.closeEntry();
          fin.close();
        }
        catch (IOException e) {
          System.err.println(e);    
        }
      }
      zout.close();    
    }
    catch (Exception e) {
      System.err.println(e);
    }
  
  }
  
}
