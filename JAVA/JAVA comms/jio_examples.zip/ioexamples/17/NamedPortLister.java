import javax.comm.*;


public class NamedPortLister {

  public static void main(String[] args) {

    // list serial (COM) ports
    try {
      int portNumber = 1;
      while (true) {
        CommPortIdentifier.getPortIdentifier("COM" + portNumber);
        System.out.println("COM" + portNumber);
        portNumber++;
      }
    }
    catch (NoSuchPortException e) {
      // break out of loop
    }

    // list parallel (LPT) ports
    try {
      int portNumber = 1;
      while (true) {
        CommPortIdentifier.getPortIdentifier("LPT" + portNumber);
        System.out.println("LPT" + portNumber);
        portNumber++;
      }
    }
    catch (NoSuchPortException e) {
      // break out of loop
    }

  }

}
