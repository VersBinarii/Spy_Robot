import java.awt.*;
import javax.swing.*;


public class ModePanel extends JPanel {

  JCheckBox bigEndian = new JCheckBox("Big Endian", true);
  JCheckBox deflated = new JCheckBox("Deflated", false);
  JCheckBox gzipped = new JCheckBox("GZipped", false);
  
  ButtonGroup dataTypes = new ButtonGroup();
  JRadioButton asciiRadio   = new JRadioButton("ASCII");
  JRadioButton decimalRadio = new JRadioButton("Decimal");
  JRadioButton hexRadio     = new JRadioButton("Hexadecimal");
  JRadioButton shortRadio   = new JRadioButton("Short");
  JRadioButton intRadio     = new JRadioButton("Int");
  JRadioButton longRadio    = new JRadioButton("Long");
  JRadioButton floatRadio   = new JRadioButton("Float");
  JRadioButton doubleRadio  = new JRadioButton("Double");
  
  JTextField password = new JTextField();
  
  
  public ModePanel() {
  
    this.setLayout(new GridLayout(13, 1));
    this.add(bigEndian);
    this.add(deflated);
    this.add(gzipped);
    
    this.add(asciiRadio);
    asciiRadio.setSelected(true);
    this.add(decimalRadio);
    this.add(hexRadio);
    this.add(shortRadio);
    this.add(intRadio);
    this.add(longRadio);
    this.add(floatRadio);
    this.add(doubleRadio);
    
    
    dataTypes.add(asciiRadio);
    dataTypes.add(decimalRadio);
    dataTypes.add(hexRadio);
    dataTypes.add(shortRadio);
    dataTypes.add(intRadio);
    dataTypes.add(longRadio);
    dataTypes.add(floatRadio);
    dataTypes.add(doubleRadio);
    
    this.add(password);
  }

  public boolean isBigEndian() {
    return bigEndian.isSelected();
  }
  
  public boolean isDeflated() {
    return deflated.isSelected();
  }
  
  public boolean isGZipped() {
    return gzipped.isSelected();
  }
  
  public int getMode() {

    if (asciiRadio.isSelected()) return FileDumper5.ASC;
    else if (decimalRadio.isSelected()) return FileDumper5.DEC;
    else if (hexRadio.isSelected()) return FileDumper5.HEX;
    else if (shortRadio.isSelected()) return FileDumper5.SHORT;
    else if (intRadio.isSelected()) return FileDumper5.INT;
    else if (longRadio.isSelected()) return FileDumper5.LONG;
    else if (floatRadio.isSelected()) return FileDumper5.FLOAT;
    else if (doubleRadio.isSelected()) return FileDumper5.DOUBLE;
    else return FileDumper5.ASC;
    
  }
  
  public String getPassword() {
    return password.getText();
  }

}
