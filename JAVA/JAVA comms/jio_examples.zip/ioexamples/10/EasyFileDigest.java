import java.net.*;
import java.io.*;
import com.macfaq.security.*;
import com.macfaq.io.*;

public class EasyFileDigest {

  public static void main(String[] args) {

    if (args.length != 2) {
      System.err.println("Usage: java FileDigest url filename");
      return;
    }

    try {
      URL u = new URL(args[0]);
      FileOutputStream out = new FileOutputStream(args[1]);
      EasyDigestOutputStream edout = new EasyDigestOutputStream(out, "SHA");
      StreamCopier.copy(u.openStream(), edout);
      edout.close();
      byte[] result = edout.getDigest();
      for (int i = 0; i < result.length; i++) {
        System.out.print(result[i] + " ");
      }
      System.out.println();
      
    }
    catch (MalformedURLException e) {
      System.err.println(args[0] + " is not a URL");
    }
    catch (Exception e) {
      System.err.println(e);
    }

  }

}
