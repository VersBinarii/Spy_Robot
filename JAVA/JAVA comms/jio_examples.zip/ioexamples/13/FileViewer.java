import javax.swing.*;
import java.io.*;
import com.macfaq.io.*;
import com.macfaq.swing.*;
import java.awt.*;
import java.awt.event.*;


public class FileViewer extends JFrame 
 implements WindowListener, ActionListener {

  JFileChooser fc = new JFileChooser();
  JStreamedTextArea theView = new JStreamedTextArea();
  ModePanel mp = new ModePanel();

  public FileViewer() {
    super("FileViewer");
  }

  public void init() {
  
    this.addWindowListener(this);
   
    fc.setApproveButtonText("View File");
    fc.setApproveButtonMnemonic('V');
    fc.addActionListener(this);
    
    this.getContentPane().add("Center", fc);
    JScrollPane sp = new JScrollPane(theView);
    this.getContentPane().add("South", sp);
    this.getContentPane().add("West", mp);
    this.pack();
    
    // center on display
    Dimension display = getToolkit().getScreenSize();
    Dimension bounds = this.getSize();   
    
    int x = (display.width - bounds.width)/2;
    int y = (display.height - bounds.height)/2;
    if (x < 0) x = 10;
    if (y < 0) y = 15;
    this.setLocation(x, y);
    
  }
  
  public void actionPerformed(ActionEvent e) {
  
    if (e.getActionCommand().equals(JFileChooser.APPROVE_SELECTION)) {
      File f = fc.getSelectedFile();
      if (f != null) {
        theView.setText("");
        OutputStream out = theView.getOutputStream();
        try {
          FileInputStream in = new FileInputStream(f);
          FileDumper5.dump(in, out, mp.getMode(), mp.isBigEndian(),
           mp.isDeflated(), mp.isGZipped(), mp.getPassword());
        }
        catch (IOException ex) {
        }
      }
      
    }
    else if (e.getActionCommand().equals(JFileChooser.CANCEL_SELECTION)) {
      this.closeAndQuit();
    }
    
  }

  public void windowClosing(WindowEvent e) {
    this.closeAndQuit();
  }
  
  // Do-nothing methods for WindowListener
  public void windowOpened(WindowEvent e) {}
  
  public void windowClosed(WindowEvent e) {}
  public void windowIconified(WindowEvent e) {}
  public void windowDeiconified(WindowEvent e) {}
  public void windowActivated(WindowEvent e) {}  
  public void windowDeactivated(WindowEvent e) {}

  private void closeAndQuit() {
  
    this.setVisible(false);
    this.dispose();
    
    //
    System.exit(0);
  
  }

  public static void main(String[] args) {
  
    FileViewer fv = new FileViewer();
    fv.init();
    fv.show();
    
  }

}
