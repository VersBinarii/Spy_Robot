import java.io.*;
import javax.swing.*;
import com.macfaq.io.*;


public class JFileTyper {

  public static void main(String[] args) {
    
    JFileChooser fc = new JFileChooser();
    int result = fc.showOpenDialog(new JFrame());
    if (result == JFileChooser.APPROVE_OPTION) {
      try {
        File f = fc.getSelectedFile();
        if (f != null) { // make sure the user didn't choose a directory
          FileInputStream fin = new FileInputStream(f);
          StreamCopier.copy(fin, System.out);
          fin.close();
        }
      }
      catch (IOException e) {
        System.err.println(e);
      }
      
    }
    
    // Work around annoying AWT non-daemon thread bug
    System.exit(0);

  }
  
}
