import java.io.*;
import java.security.*;
import java.security.spec.*;
import javax.crypto.*;
import javax.crypto.spec.*;
import com.sun.crypto.provider.*;


public class BlowfishEncryptor {

  public static void main(String[] args) {

    if (args.length != 2) {
      System.err.println("Usage: java FileEncryptor filename password");
      return;
    }

    String filename = args[0];
    String password = args[1];

    if (password.length() < 8 ) {
      System.err.println("Password must be at least eight characters long");
    }
    
    
    
    try {

      FileInputStream fin = new FileInputStream(args[0]);
      FileOutputStream fout = new FileOutputStream(args[0] + ".bwf");

  KeyGenerator blowfishKeyGenerator = KeyGenerator.getInstance("Blowfish");
  SecretKey blowfishKey = blowfishKeyGenerator.generateKey();
/*  byte[] keyData = blowfishKey.getEncoded();
  SecretKeySpec blowfishKeySpec = new SecretKeySpec(keyData, "Blowfish");
*/

      // create a key
 /*     byte[] blowfishKeyData = password.getBytes();
      SecretKeySpec blowfishKeySpec = new SecretKeySpec(blowfishKeyData, "Blowfish");
*/
      
      // SecretKey blowfishKey = keyFactory.generateSecret(blowfishKeySpec);

      // use Data Encryption Standard
      Cipher des = Cipher.getInstance("Blowfish/ECB/PKCS5Padding");
      des.init(Cipher.ENCRYPT_MODE, blowfishKey);
            
      byte[] input = new byte[64];
      while (true) {
        int bytesRead = fin.read(input);
        if (bytesRead == -1) break;
        byte[] output = des.update(input, 0, bytesRead);
        if (output != null) fout.write(output);
      }
      
      byte[] output = des.doFinal();
      if (output != null) fout.write(output);
      fin.close();
      fout.flush();
      fout.close();

    }
    catch (GeneralSecurityException e) {
      System.err.println(e);
      e.printStackTrace();
    }
    catch (IOException e) {
      System.err.println(e);
    }

  }

} 
