import java.util.*;
import java.util.zip.*;
import java.io.*;
import com.macfaq.io.*;


public class Unzipper2 {

  public static void main(String[] args) {

    for (int i = 0; i < args.length; i++) {
      try {
        FileInputStream fin = new FileInputStream(args[i]);
        ZipInputStream zin = new ZipInputStream(fin);
        ZipEntry ze = null;
        while ((ze = zin.getNextEntry()) != null) {
          System.out.println("Unzipping " + ze.getName());
          FileOutputStream fout = new FileOutputStream(ze.getName());
          StreamCopier.copy(zin, fout);
          zin.closeEntry();
          fout.close();
        }
        zin.close();
      }
      catch (IOException e) {
        System.err.println(e);
        e.printStackTrace();
      }       
    }

  }

}
