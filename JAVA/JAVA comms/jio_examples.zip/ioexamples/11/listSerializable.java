import java.util.*;
import java.util.zip.*;
import java.io.*;
import java.lang.reflect.*;
import java.awt.*;


public class listSerializable {

  public static void main(String[] args) {
  
    String[] prefixes = { "java.applet",
     "java.awt",
     "java.awt.datatransfer",
     "java.awt.event",
     "java.awt.image",
     "java.beans",
     "java.io",
     "java.lang",
     "java.lang.reflect",
     "java.math",
     "java.net",
     "java.rmi",
     "java.rmi.dgc",
     "java.rmi.registry",
     "java.rmi.server",
     "java.security",
     "java.security.acl",
     "java.security.interfaces",
     "java.sql",
     "java.text",
     "java.util",
     "java.util.zip"};
    String classname = "";
    FileDialog fd = new FileDialog(new Frame(), "Please locate classes.zip: ", FileDialog.LOAD);
    fd.setVisible(true);
    String filename = fd.getDirectory() + fd.getFile();
    
 /*   try {
      prefix = args[0];
      if (!prefix.endsWith(".")) prefix += ".";
    }
    catch (ArrayIndexOutOfBoundsException e) {
    
    }  */
    
    for (int i = 0; i < prefixes.length; i++) {
      String prefix = prefixes[i] + ".";
      System.out.println(prefix + ":\n");
      try {
        ZipFile zf = new ZipFile(filename);
        Enumeration files = zf.entries();
        while (files.hasMoreElements()) {
          ZipEntry ze = (ZipEntry) files.nextElement();
          classname = ze.getName().replace('/','.');
          if (classname.startsWith(prefix) && classname.endsWith(".class") 
            && !classname.startsWith("sun.tools.javadoc.MIFPrintStream") 
            && !classname.startsWith("sun.awt.motif.X11Selection.class")
            && !classname.startsWith("sun.awt.tiny.TinyWindowFrame")
            && !classname.startsWith("sun.awt.tiny.TinyMenuBarPeer")) {
  //          System.err.println(classname);
            classname = classname.substring(0,classname.length() - 6); 
            try {
              Class thisClass = Class.forName(classname);
              classname = classname.substring(prefix.length()); 
              if (classname.indexOf('.') != -1 || classname.indexOf('$') != -1 ) continue;
              Class superclass = thisClass;
              Class[] theInterfaces  = thisClass.getInterfaces();
              while (superclass.getSuperclass() != null) {
                if (implementsSerializable(superclass)) {
                  System.out.print(classname + ", ");
                  break;
                }
                superclass = superclass.getSuperclass();
              }
            }
            catch (InternalError ie) {
              System.err.println(ie);
            }
          }
        } 
      }
      catch (ClassNotFoundException e) {
        System.err.println(e + " " + classname);  
      }  
      catch (Exception e) {
        System.err.println(e);  
      }  
      catch (Throwable t) {
       System.err.println(t);
     }   
     System.out.println();
    } 
   
  }

  public static boolean implementsSerializable(Class c) {
  
    Class[] theInterfaces  = c.getInterfaces();
    for (int i = 0; i < theInterfaces.length; i++) {
      if (theInterfaces[i].getName().endsWith("Serializable")) {
        return true;
      }
    }
    return false;
    
  }

}